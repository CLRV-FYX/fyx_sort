// Counting-sort fast path conformance tests (weapon two), explicit
// parallel sample-sort dispatch sanity (weapon three), and top-level input
// profiling/dispatch checks (weapon seven).
#define FYX_ENABLE_TEST_HOOKS 1
#include "../fyx_sort.hpp"

#include <algorithm>
#include <cstdlib>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <numeric>
#include <random>
#include <string>
#include <unordered_map>
#include <vector>

static int failures = 0;
#define CHECK(c, m) do { if (!(c)) { std::printf("  FAIL: %s\n", m); ++failures; } } while (0)

// High-entropy numeric input is claimed by one of the two full-range numeric
// kernels: the AVX-512 vectorised quicksort where the CPU has it, the radix
// family everywhere else.  Which one is a machine property, so the dispatch
// checks below accept either and the point of the check -- that the range does
// not fall through to a comparison sort -- is unchanged.
static bool is_numeric_kernel(fyx::detail::DispatchDecision d) {
    return d == fyx::detail::DispatchDecision::Radix ||
           d == fyx::detail::DispatchDecision::VectorQuick;
}

template <class T, class Comp = std::less<T>>
static void check_against_std(const char* tag, std::vector<T> v, Comp comp = Comp{}) {
    std::vector<T> ref = v;
    std::sort(ref.begin(), ref.end(), comp);
    fyx::sort(v, comp);
    CHECK(v == ref, tag);
}

int main() {
    std::mt19937_64 rng(0xC0FFEE);

    std::printf("counting: dense integer ranges\n");
    {
        std::vector<int> v(300000);
        for (auto& x : v) x = static_cast<int>(rng() % 17) - 8;
        check_against_std("i32 dense low range", v);
        check_against_std("i32 dense low range descending", v, std::greater<int>{});
    }
    {
        std::vector<unsigned char> v(200000);
        for (auto& x : v) x = static_cast<unsigned char>(rng() & 0xFFu);
        check_against_std("u8 full 256 range", v);
    }

    std::printf("counting: sparse low-cardinality integers\n");
    {
        std::vector<std::int64_t> keys(256);
        for (std::size_t i = 0; i < keys.size(); ++i)
            keys[i] = (static_cast<std::int64_t>(i) - 128) * 1000000000037LL;
        std::vector<std::int64_t> v(350000);
        for (auto& x : v) x = keys[rng() % keys.size()];
        check_against_std("i64 sparse 256 distinct", v);
    }
    {
        // 257 distinct must remain correct even when the compressed counter
        // declines and falls back to the normal path.
        std::vector<std::int64_t> v(120000);
        for (std::size_t i = 0; i < v.size(); ++i)
            v[i] = static_cast<std::int64_t>(i % 257) * 999999937LL - 1234567LL;
        std::shuffle(v.begin(), v.end(), rng);
        check_against_std("i64 sparse 257 distinct fallback", v);
    }
#if FYX_ENABLE_PARALLEL
    {
        std::vector<std::uint32_t> keys;
        keys.reserve(256);
        while (keys.size() < 256) {
            const std::uint32_t x = static_cast<std::uint32_t>(rng());
            if (std::find(keys.begin(), keys.end(), x) == keys.end()) keys.push_back(x);
        }
        std::vector<std::uint32_t> v(350000);
        for (auto& x : v) x = keys[rng() % keys.size()];
        const bool ok_path = fyx::detail::try_radix_key_rank16_count_sort_parallel(v.data(), v.size(), false);
        CHECK(ok_path, "parallel uint32 rank16 count path accepted sparse 256-way lowcard");
        CHECK(std::is_sorted(v.begin(), v.end()), "parallel uint32 rank16 count output");
    }
#endif

    std::printf("counting: strings and payload structs\n");
    {
        std::vector<std::string> alpha;
        for (int i = 0; i < 64; ++i) alpha.push_back("key_" + std::to_string(i));
        std::vector<std::string> v(180000);
        for (auto& s : v) s = alpha[rng() % alpha.size()];
        check_against_std("string 64 distinct", v);
        check_against_std("string 64 distinct descending", v, std::greater<std::string>{});
        auto natural = [](const std::string& a, const std::string& b) { return a < b; };
        check_against_std("string 64 distinct custom natural comparator", v, natural);
#if FYX_ENABLE_PARALLEL
        std::vector<std::string> pv(300000);
        for (auto& s : pv) s = alpha[rng() % alpha.size()];
        const bool ok_parallel = fyx::detail::try_string_value_count_sort_parallel(pv.data(), pv.size(), natural, false);
        CHECK(ok_parallel, "parallel string value-count accepted custom comparator lowcard");
        CHECK(std::is_sorted(pv.begin(), pv.end(), natural), "parallel string value-count output");
#endif
    }
    {
        struct Rec {
            int key;
            int payload;
            bool operator==(const Rec& o) const { return key == o.key && payload == o.payload; }
        };
        auto by_key = [](const Rec& a, const Rec& b) { return a.key < b.key; };
        std::vector<Rec> v(50000);
        for (std::size_t i = 0; i < v.size(); ++i)
            v[i] = {static_cast<int>(rng() % 31), static_cast<int>(i)};

        std::vector<Rec> got = v;
        fyx::sort(got, by_key);
        CHECK(std::is_sorted(got.begin(), got.end(), by_key), "struct by-key sorted");
        std::vector<int> seen(v.size(), 0);
        for (const Rec& r : got) if (r.payload >= 0 && static_cast<std::size_t>(r.payload) < seen.size()) ++seen[r.payload];
        CHECK(std::all_of(seen.begin(), seen.end(), [](int c) { return c == 1; }), "struct payload permutation preserved");

        std::vector<Rec> ref = v;
        std::stable_sort(ref.begin(), ref.end(), by_key);
        fyx::stable_sort(v, by_key);
        CHECK(v == ref, "stable struct by-key low cardinality");
    }
    {
        struct Rec {
            int key;
            int payload;
            bool operator==(const Rec& o) const { return key == o.key && payload == o.payload; }
        };
        auto by_key = [](const Rec& a, const Rec& b) { return a.key < b.key; };
        std::vector<Rec> v(180000);
        for (std::size_t i = 0; i < v.size(); ++i)
            v[i] = {static_cast<int>(rng() % 100000), static_cast<int>(i)};
        std::vector<Rec> got = v;
        fyx::sort(got, by_key);
        CHECK(std::is_sorted(got.begin(), got.end(), by_key), "struct by-key high distinct sorted");
        std::vector<int> seen(v.size(), 0);
        for (const Rec& r : got) if (r.payload >= 0 && static_cast<std::size_t>(r.payload) < seen.size()) ++seen[r.payload];
        CHECK(std::all_of(seen.begin(), seen.end(), [](int c) { return c == 1; }), "struct by-key high distinct payload permutation");
        auto by_key_desc = [](const Rec& a, const Rec& b) { return a.key > b.key; };
        got = v;
        fyx::sort(got, by_key_desc);
        CHECK(std::is_sorted(got.begin(), got.end(), by_key_desc), "struct by-key high distinct descending sorted");
    }
    {
        auto abs_less = [](int a, int b) { return std::abs(a) < std::abs(b); };
        std::vector<int> v(60000);
        for (auto& x : v) x = static_cast<int>(rng() % 200000) - 100000;
        std::vector<int> ref = v;
        std::sort(ref.begin(), ref.end());
        fyx::Options o;
        o.parallel = fyx::Tri::On;
        fyx::sort(v, abs_less, o);
        CHECK(std::is_sorted(v.begin(), v.end(), abs_less), "parallel merge custom abs comparator sorted");
        std::sort(v.begin(), v.end());
        CHECK(v == ref, "parallel merge custom abs comparator permutation");
    }

    std::printf("input profile top-level dispatch\n");
    {
        namespace fd = fyx::detail;
        std::vector<int> v(4096);
        std::iota(v.begin(), v.end(), 0);
        fd::test_reset_dispatch();
        fyx::sort(v);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::ProfileSorted,
              "profile sorted direct return");
        CHECK(std::is_sorted(v.begin(), v.end()), "profile sorted output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<int> v(4096);
        for (std::size_t i = 0; i < v.size(); ++i) v[i] = static_cast<int>(v.size() - i);
        fd::test_reset_dispatch();
        fyx::sort(v);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::ProfileReverse,
              "profile reverse direct reverse");
        CHECK(std::is_sorted(v.begin(), v.end()), "profile reverse output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<int> v(4096, 7);
        fd::test_reset_dispatch();
        fyx::sort(v);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::ProfileAllEqual,
              "profile all-equal direct return");
        CHECK(std::all_of(v.begin(), v.end(), [](int x) { return x == 7; }),
              "profile all-equal output");
    }
    {
        namespace fd = fyx::detail;
        auto natural = [](const int& a, const int& b) { return a < b; };
        std::vector<int> v(4096);
        std::iota(v.begin(), v.end(), 0);
        fd::test_reset_dispatch();
        fyx::sort(v, natural);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::ProfileSorted,
              "natural comparator sorted fast exit");
    }
    {
        namespace fd = fyx::detail;
        auto natural = [](const int& a, const int& b) { return a < b; };
        std::vector<int> v(4096);
        for (std::size_t i = 0; i < v.size(); ++i) v[i] = static_cast<int>(v.size() - i);
        fd::test_reset_dispatch();
        fyx::sort(v, natural);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::ProfileReverse,
              "natural comparator reverse fast exit");
        CHECK(std::is_sorted(v.begin(), v.end(), natural), "natural comparator reverse output");
    }
    {
        namespace fd = fyx::detail;
        auto natural = [](const int& a, const int& b) { return a < b; };
        std::vector<int> v(4096, 7);
        fd::test_reset_dispatch();
        fyx::sort(v, natural);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::ProfileAllEqual,
              "natural comparator all-equal fast exit");
    }
    {
        namespace fd = fyx::detail;
        std::vector<int> v(200000);
        for (auto& x : v) x = static_cast<int>(rng() % 17) - 8;
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::Off;
        fyx::sort(v, o);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::LowCardinality,
              "profile low-cardinality chooses counting");
        CHECK(std::is_sorted(v.begin(), v.end()), "profile low-cardinality output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<int> v(200000);
        for (auto& x : v) x = static_cast<int>(rng());
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::Off;
        fyx::sort(v.begin(), v.end(), o);
        CHECK(is_numeric_kernel(fd::test_last_dispatch()),
              "vector iterator numeric random uses a pointer numeric kernel");
        CHECK(std::is_sorted(v.begin(), v.end()), "vector iterator numeric random output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<int> v(200000);
        for (auto& x : v) x = static_cast<int>(rng());
        auto less_lambda = [](int a, int b) { return a < b; };
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::Off;
        fyx::sort(v.begin(), v.end(), less_lambda, o);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::Radix,
              "custom numeric less lambda recovers guarded radix path");
        CHECK(std::is_sorted(v.begin(), v.end(), less_lambda),
              "custom numeric less lambda guarded radix output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<float> keys(16);
        for (std::size_t i = 0; i < keys.size(); ++i)
            keys[i] = static_cast<float>(static_cast<int>(i) - 8) * 1.25f;
        std::vector<float> v(200000);
        for (auto& x : v) x = keys[rng() % keys.size()];
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::Off;
        fyx::sort(v.begin(), v.end(), o);
        // On AVX-512 hosts the vector quicksort's equal-key handling beats
        // the sparse counter on this shape (vq_beats_sparse_count).
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::LowCardinality ||
              fd::test_last_dispatch() == fd::DispatchDecision::VectorQuick,
              "vector iterator float low-cardinality uses radix-key sparse count");
        CHECK(std::is_sorted(v.begin(), v.end()), "vector iterator float low-cardinality output");
    }
#if FYX_ENABLE_PARALLEL
    {
        namespace fd = fyx::detail;
        std::vector<float> keys(256);
        for (std::size_t i = 0; i < keys.size(); ++i)
            keys[i] = static_cast<float>(static_cast<int>(i) - 128) * 0.5f;
        std::vector<float> v((std::size_t(1) << 20) + 17);
        for (auto& x : v) x = keys[rng() % keys.size()];
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::On;
        fyx::sort(v.begin(), v.end(), o);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::LowCardinality,
              "parallel float low-cardinality uses rank/direct-map count");
        CHECK(std::is_sorted(v.begin(), v.end()), "parallel float low-cardinality output");
    }
#endif
#if FYX_ENABLE_PARALLEL
    {
        std::uniform_real_distribution<float> dist(-1000000.0f, 1000000.0f);
        std::vector<float> keys;
        keys.reserve(256);
        while (keys.size() < 256) {
            const float x = dist(rng);
            if (std::find(keys.begin(), keys.end(), x) == keys.end()) keys.push_back(x);
        }
        std::vector<float> v((std::size_t(1) << 20) + 17);
        for (auto& x : v) x = keys[rng() % keys.size()];
        const bool ok_path = fyx::detail::try_radix_key_rank16_count_sort_parallel(v.data(), v.size(), false);
        CHECK(ok_path, "parallel float rank16 count path accepted arbitrary 256-way lowcard");
        CHECK(std::is_sorted(v.begin(), v.end()), "parallel float rank16 count output");
    }
#endif
#if FYX_ENABLE_PARALLEL
    {
        std::vector<std::int32_t> v((std::size_t(1) << 20) + 17);
        for (auto& x : v) x = static_cast<std::int32_t>(rng() % 256) - 128;
        const bool ok_path = fyx::detail::try_integer_range_count_sort_parallel(v.data(), v.size(), false);
        CHECK(ok_path, "parallel int32 dense-range count path accepted 256-way lowcard");
        CHECK(std::is_sorted(v.begin(), v.end()), "parallel int32 dense-range count output");
    }
#endif
    {
        namespace fd = fyx::detail;
        std::vector<std::int32_t> keys = {
            std::numeric_limits<std::int32_t>::min(), -1234567890, -77777777, -1024,
            -7, 0, 3, 19, 1024, 65537, 77777777, 123456789, 987654321,
            1357913579, 1900000000, std::numeric_limits<std::int32_t>::max()
        };
        std::vector<std::int32_t> v((std::size_t(1) << 20) + 17);
        for (auto& x : v) x = keys[rng() % keys.size()];
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::On;
        fyx::sort(v.begin(), v.end(), o);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::LowCardinality,
              "parallel int32 sparse low-cardinality uses sparse count");
        CHECK(std::is_sorted(v.begin(), v.end()), "parallel int32 sparse low-cardinality output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<std::int32_t> v((std::size_t(1) << 20) + 17);
        for (auto& x : v) x = static_cast<std::int32_t>(rng());
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::On;
        fyx::sort(v.begin(), v.end(), o);
        CHECK(is_numeric_kernel(fd::test_last_dispatch()),
              "parallel int32 high-entropy uses a numeric kernel");
        CHECK(std::is_sorted(v.begin(), v.end()), "parallel int32 high-entropy output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<std::uint64_t> v((std::size_t(1) << 20) + 17);
        for (auto& x : v) x = rng();
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::On;
        fyx::sort(v.begin(), v.end(), o);
        CHECK(is_numeric_kernel(fd::test_last_dispatch()),
              "parallel uint64 high-entropy uses a numeric kernel");
        CHECK(std::is_sorted(v.begin(), v.end()), "parallel uint64 high-entropy output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<double> v((std::size_t(1) << 20) + 17);
        for (auto& x : v) {
            const std::int64_t raw = static_cast<std::int64_t>(rng());
            x = static_cast<double>(raw) * 0.25;
        }
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::On;
        fyx::sort(v.begin(), v.end(), o);
        CHECK(is_numeric_kernel(fd::test_last_dispatch()),
              "parallel double high-entropy uses a numeric kernel");
        CHECK(std::is_sorted(v.begin(), v.end()), "parallel double high-entropy output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<float> keys(16);
        for (std::size_t i = 0; i < keys.size(); ++i)
            keys[i] = static_cast<float>(static_cast<int>(i) - 8) * 0.5f;
        std::vector<float> v((std::size_t(1) << 20) + 17);
        for (auto& x : v) x = keys[rng() % keys.size()];
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::On;
        fyx::sort(v.begin(), v.end(), o);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::LowCardinality,
              "parallel float low-cardinality uses radix-key sparse count");
        CHECK(std::is_sorted(v.begin(), v.end()), "parallel float low-cardinality output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<int> v(200000);
        std::iota(v.begin(), v.end(), 0);
        for (std::size_t i = 1000; i + 1 < v.size(); i += 4096)
            std::swap(v[i], v[i + 1]);
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::Off;
        fyx::sort(v, o);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq,
              "profile partially-sorted chooses bounded insertion/pdq repair");
        CHECK(std::is_sorted(v.begin(), v.end()), "profile partially-sorted output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<double> v(200000);
        for (std::size_t i = 0; i < v.size(); ++i)
            v[i] = static_cast<double>(i);
        for (std::size_t i = 2000; i + 1 < v.size(); i += 8192)
            std::swap(v[i], v[i + 1]);
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::Off;
        fyx::sort(v, o);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq,
              "floating nearly-sorted keeps radix-order repair dispatch");
        CHECK(std::is_sorted(v.begin(), v.end()), "floating nearly-sorted output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<std::int32_t> v((std::size_t(1) << 20) + 17);
        for (auto& x : v) x = static_cast<std::int32_t>(rng());
        std::sort(v.begin(), v.end());
        for (std::size_t k = 0; k < v.size() / 100; ++k) {
            const std::size_t a = static_cast<std::size_t>(rng() % v.size());
            const std::size_t b = static_cast<std::size_t>(rng() % v.size());
            std::swap(v[a], v[b]);
        }
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::On;
        fyx::sort(v, o);
        // Sparse long-distance swaps leave a dirty set behind.  Repairing it
        // with the patch merge's three linear passes beats the radix fallback
        // this case used to take; where an AVX-512 quicksort exists it beats
        // the patch merge in turn once the dirt is a percent of the range and
        // a pool is available (see patch_merge_dirty_budget), so both answers
        // are correct and which one appears is a property of the machine.
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq ||
              fd::test_last_dispatch() == fd::DispatchDecision::VectorQuick,
              "long-distance numeric nearly-sorted uses a repair or the quicksort");
        CHECK(std::is_sorted(v.begin(), v.end()), "long-distance numeric nearly-sorted output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<double> v((std::size_t(1) << 20) + 17);
        for (std::size_t i = 0; i < v.size(); ++i)
            v[i] = static_cast<double>(i);
        for (std::size_t k = 0; k < v.size() / 100; ++k) {
            const std::size_t a = static_cast<std::size_t>(rng() % v.size());
            const std::size_t b = static_cast<std::size_t>(rng() % v.size());
            std::swap(v[a], v[b]);
        }
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::On;
        fyx::sort(v, o);
        // Values 0..n-1 as doubles: once the patch merge steps aside for the
        // quicksort (dirt of a percent, pool available) the permutation-range
        // radix kernel gets its turn and is the fastest of the three here --
        // 0.0037 s against 0.0067 for the quicksort and 0.0089 for the patch
        // merge.  Any of the three is a correct answer; a comparison sort is
        // not, which is what this check is for.
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq ||
              fd::test_last_dispatch() == fd::DispatchDecision::VectorQuick ||
              fd::test_last_dispatch() == fd::DispatchDecision::Radix,
              "floating integer-permutation nearly-sorted keeps a numeric kernel");
        CHECK(std::is_sorted(v.begin(), v.end()), "floating integer-permutation nearly-sorted output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<int> v(8192);
        for (std::size_t i = 0; i < v.size(); ++i)
            v[i] = static_cast<int>((i % 2 == 0) ? (i / 2) : (v.size() - i / 2));
        fd::test_reset_dispatch();
        fyx::sort(v);
        // AVX-512 hosts send small numeric ranges to the vector quicksort,
        // which beats the structural repair kernel on this shape.
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq ||
              fd::test_last_dispatch() == fd::DispatchDecision::VectorQuick,
              "interleaved zigzag runs use linear two-run merge");
        CHECK(std::is_sorted(v.begin(), v.end()), "interleaved zigzag output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<int> v(8192);
        std::iota(v.begin(), v.end(), 0);
        for (std::size_t i = 0; i + 1 < v.size(); i += 2)
            std::swap(v[i], v[i + 1]);
        fd::test_reset_dispatch();
        fyx::sort(v);
        // AVX-512 hosts send small numeric ranges to the vector quicksort,
        // which beats the structural repair kernel on this shape.
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq ||
              fd::test_last_dispatch() == fd::DispatchDecision::VectorQuick,
              "adjacent-swap zigzag uses in-place pair repair");
        CHECK(std::is_sorted(v.begin(), v.end()), "adjacent-swap zigzag output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<int> v(8192);
        std::iota(v.begin(), v.end(), 0);
        std::reverse(v.begin(), v.begin() + static_cast<std::ptrdiff_t>(v.size() / 2));
        fd::test_reset_dispatch();
        fyx::sort(v);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq,
              "front-reversed organ-pipe zigzag only reverses first half");
        CHECK(std::is_sorted(v.begin(), v.end()), "front-reversed organ-pipe output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<int> v(8192);
        for (std::size_t i = 0; i < v.size(); ++i)
            v[i] = static_cast<int>((i < v.size() / 2) ? (i * 2) : ((v.size() - i) * 2 - 1));
        fd::test_reset_dispatch();
        fyx::sort(v);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq,
              "numeric half-organ zigzag uses arithmetic fill");
        CHECK(std::is_sorted(v.begin(), v.end()), "numeric half-organ zigzag output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<double> v(8192);
        for (std::size_t i = 0; i < v.size(); ++i)
            v[i] = static_cast<double>((i < v.size() / 2) ? (i * 2) : ((v.size() - i) * 2 - 1));
        fd::test_reset_dispatch();
        fyx::sort(v);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq,
              "floating half-organ zigzag uses arithmetic fill");
        CHECK(std::is_sorted(v.begin(), v.end()), "floating half-organ zigzag output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<std::string> v(8192);
        for (std::size_t i = 0; i < v.size(); ++i) {
            const std::size_t key = (i % 2 == 0) ? (i / 2) : (v.size() - i / 2);
            v[i] = std::to_string(1000000000u + static_cast<unsigned>(key));
        }
        fd::test_reset_dispatch();
        fyx::sort(v);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq,
              "string interleaved zigzag runs use two-run merge");
        CHECK(std::is_sorted(v.begin(), v.end()), "string interleaved zigzag output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<std::string> v(8192);
        for (std::size_t i = 0; i < v.size(); ++i)
            v[i] = std::to_string(1000000000u + static_cast<unsigned>(i));
        std::reverse(v.begin(), v.begin() + static_cast<std::ptrdiff_t>(v.size() / 2));
        fd::test_reset_dispatch();
        fyx::sort(v);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq,
              "string front-reversed organ-pipe zigzag only reverses first half");
        CHECK(std::is_sorted(v.begin(), v.end()), "string front-reversed organ-pipe output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<std::string> v(8192);
        for (std::size_t i = 0; i < v.size(); ++i) {
            const std::size_t key = (i < v.size() / 2) ? (i * 2) : ((v.size() - i) * 2 - 1);
            v[i] = std::to_string(1000000000u + static_cast<unsigned>(key));
        }
        fd::test_reset_dispatch();
        fyx::sort(v);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq,
              "string half-organ zigzag uses half-buffer reorder");
        CHECK(std::is_sorted(v.begin(), v.end()), "string half-organ zigzag output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<int> v(8192);
        for (std::size_t i = 0; i < v.size(); ++i) {
            const std::size_t block = i / 4;
            const std::size_t r = i & 3u;
            const std::size_t vals[4] = {block * 4, block * 4 + 3, block * 4 + 1, block * 4 + 2};
            v[i] = static_cast<int>(vals[r]);
        }
        fd::test_reset_dispatch();
        fyx::sort(v);
        // AVX-512 hosts send small numeric ranges to the vector quicksort,
        // which beats the structural repair kernel on this shape.
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq ||
              fd::test_last_dispatch() == fd::DispatchDecision::VectorQuick,
              "local sawtooth zigzag uses bounded insertion repair");
        CHECK(std::is_sorted(v.begin(), v.end()), "local sawtooth zigzag output");
    }
    {
        namespace fd = fyx::detail;
        std::vector<std::string> v(8192);
        for (std::size_t i = 0; i < v.size(); ++i) {
            const std::size_t block = i / 4;
            const std::size_t r = i & 3u;
            const std::size_t vals[4] = {block * 4, block * 4 + 3, block * 4 + 1, block * 4 + 2};
            v[i] = std::to_string(1000000000u + static_cast<unsigned>(vals[r]));
        }
        fd::test_reset_dispatch();
        fyx::sort(v);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::PartialPdq,
              "string local sawtooth zigzag uses bounded insertion repair");
        CHECK(std::is_sorted(v.begin(), v.end()), "string local sawtooth zigzag output");
    }
    {
        namespace fd = fyx::detail;
        struct Rec {
            int key;
            int payload;
            bool operator==(const Rec& o) const { return key == o.key && payload == o.payload; }
        };
        auto by_key = [](const Rec& a, const Rec& b) { return a.key < b.key; };
        std::vector<Rec> v(200000);
        for (std::size_t i = 0; i < v.size(); ++i)
            v[i] = {static_cast<int>(rng() % 1000000), static_cast<int>(i)};
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::Off;
        fyx::sort(v, by_key, o);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::Radix,
              "profile high-entropy struct-key chooses comparator-key radix");
        CHECK(std::is_sorted(v.begin(), v.end(), by_key), "profile high-entropy struct-key output");
    }

    std::printf("string MSD lexicographic edge cases\n");
    {
        namespace fd = fyx::detail;
        std::vector<std::string> v(30000);
        for (auto& s : v) {
            const std::size_t len = static_cast<std::size_t>(rng() % 9);
            s.resize(len);
            for (char& c : s) c = static_cast<char>(rng() & 0xFFu);
        }
        check_against_std("string MSD random bytes", v, std::less<std::string>{});
        check_against_std("string MSD random bytes descending", v, std::greater<std::string>{});

        auto less_lambda = [](const std::string& a, const std::string& b) { return a < b; };
        fd::test_reset_dispatch();
        fyx::Options o;
        o.parallel = fyx::Tri::Off;
        fyx::sort(v.begin(), v.end(), less_lambda, o);
        CHECK(fd::test_last_dispatch() == fd::DispatchDecision::Radix,
              "custom string less lambda recovers guarded MSD path");
        CHECK(std::is_sorted(v.begin(), v.end(), less_lambda),
              "custom string less lambda guarded MSD output");
    }

    std::printf("radix monotone detector with NaN\n");
    {
        std::vector<float> v(100);
        v[0] = std::numeric_limits<float>::quiet_NaN();
        for (std::size_t i = 1; i < v.size(); ++i) v[i] = static_cast<float>(i);
        fyx::sort(v);
        bool ok = true;
        for (std::size_t i = 1; i + 1 < v.size(); ++i) if (v[i - 1] > v[i]) ok = false;
        CHECK(ok && v.back() != v.back(), "float NaN not hidden by monotone fast path");
    }

    std::printf("parallel sample sort explicit dispatch\n");
    {
        std::vector<std::string> v(300000);
        for (auto& s : v) {
            s.resize(20);
            for (char& c : s) c = static_cast<char>('a' + (rng() % 26));
        }
        std::vector<std::string> ref = v;
        std::sort(ref.begin(), ref.end());
        fyx::Options o;
        o.parallel = fyx::Tri::On;
        fyx::sort(v, o);
        CHECK(v == ref, "parallel sample strings high distinct");
    }

    // -----------------------------------------------------------------------
    // The parallel orderedness proof must return exactly the serial detector's
    // verdict on a corpus that includes shapes built specifically to fool its
    // 4096-point sample (monotone at every sampled position, inverted in
    // between; constant at every sampled position, not constant in between).
    // -----------------------------------------------------------------------
    std::printf("parallel vs serial orderedness proof equivalence\n");
    {
        namespace fd = fyx::detail;
        const std::size_t sizes[] = {(std::size_t(1) << 21), (std::size_t(1) << 21) + 3,
                                     (std::size_t(1) << 22) + 1};
        for (std::size_t n : sizes) {
            const std::size_t step = (n + 4095) / 4096;      // the sample stride
            for (int shape = 0; shape < 8; ++shape) {
                std::vector<std::int64_t> base(n);
                for (std::size_t i = 0; i < n; ++i) base[i] = static_cast<std::int64_t>(rng() % 100000);
                std::sort(base.begin(), base.end());
                switch (shape) {
                    case 1: std::reverse(base.begin(), base.end()); break;              // reverse
                    case 2: for (auto& x : base) x = 5; break;                          // all equal
                    case 3: for (std::size_t i = step / 2; i + 1 < n; i += step * 7)     // sorted, inversions only between samples
                                std::swap(base[i], base[i + 1]);
                            break;
                    case 4: for (std::size_t i = step; i + step / 3 < n; i += step)      // constant at samples, moved between
                                base[i + step / 3] = base[i / 2];
                            break;
                    case 5: base[n / 2] = base[0]; break;                               // one far drop
                    case 6: for (std::size_t k = 0; k < n / 1000 + 1; ++k) {            // few random swaps
                                std::size_t i = rng() % (n - 1); std::swap(base[i], base[i + 1]); }
                            break;
                    default: for (auto& x : base) x = static_cast<std::int64_t>(rng()); break;  // random
                }
                const fyx::less less{};
                const std::greater<std::int64_t> greater{};
                {   // ascending: the two proofs must agree
                    std::vector<std::int64_t> a = base, b = base;
                    fd::test_reset_dispatch();
                    const bool par = fd::try_parallel_fast_order_exit(a.data(), a.size(), less, true);
                    const fd::DispatchDecision dpar = fd::test_dispatch_slot();
                    fd::test_reset_dispatch();
                    const bool ser = fd::try_fast_order_exit(b.data(), b.size(), less, true);
                    const fd::DispatchDecision dser = fd::test_dispatch_slot();
                    CHECK(par == ser, "parallel and serial order verdict agree (ascending)");
                    CHECK(!par || a == b, "both proofs leave the same array (ascending)");
                    if (par) CHECK(dpar == dser, "parallel and serial order decision agree (ascending)");
                    if (par && dpar == fd::DispatchDecision::ProfileReverse && a != b) {
                        std::sort(a.begin(), a.end());
                        CHECK(std::is_sorted(a.begin(), a.end()), "reverse proof leaves sorted data");
                    }
                    if (par) CHECK(std::is_sorted(a.begin(), a.end()), "ascending proof implies sorted");
                }
                {   // descending comparator: same expectations, reverse direction
                    std::vector<std::int64_t> a = base, b = base;
                    fd::test_reset_dispatch();
                    const bool par = fd::try_parallel_fast_order_exit(a.data(), a.size(), greater, true);
                    const fd::DispatchDecision dpar = fd::test_dispatch_slot();
                    fd::test_reset_dispatch();
                    const bool ser = fd::try_fast_order_exit(b.data(), b.size(), greater, true);
                    const fd::DispatchDecision dser = fd::test_dispatch_slot();
                    CHECK(par == ser, "parallel and serial order verdict agree (descending)");
                    CHECK(!par || a == b, "both proofs leave the same array (descending)");
                    if (par) CHECK(dpar == dser, "parallel and serial order decision agree (descending)");
                    if (par) CHECK(std::is_sorted(a.begin(), a.end(), greater), "descending proof implies sorted");
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Pool-assist orderedness proof (kParallelProofMinN .. kParallelOrderMinN).
    // Below the full-parallel floor the dispatcher borrows the pool for the
    // proof only; the assist opens with a *sequential* 4096-element prefix
    // instead of the strided sample.  Same contract as the >=2M proof: the
    // verdict, the array state and the dispatch record must equal the serial
    // detector's, including shapes built to fool a prefix read (disorder only
    // after the prefix; all-equal prefix over non-constant data).  1M sizes
    // are odd on purpose so chunk seams land mid-run.
    // -----------------------------------------------------------------------
    std::printf("pool-assist orderedness proof equivalence\n");
    {
        namespace fd = fyx::detail;
        const std::size_t sizes[] = {(std::size_t(1) << 20), (std::size_t(1) << 20) + 3};
        for (std::size_t n : sizes) {
            const std::size_t step = (n + 4095) / 4096;      // strided-sample step
            for (int shape = 0; shape < 8; ++shape) {
                std::vector<std::int64_t> base(n);
                for (std::size_t i = 0; i < n; ++i) base[i] = static_cast<std::int64_t>(rng() % 100000);
                std::sort(base.begin(), base.end());
                switch (shape) {
                    case 1: std::reverse(base.begin(), base.end()); break;              // reverse
                    case 2: for (auto& x : base) x = 5; break;                          // all equal
                    case 3: for (std::size_t i = step / 2; i + 1 < n; i += step * 7)     // sorted at the prefix, inversions only between strided samples
                                std::swap(base[i], base[i + 1]);
                            break;
                    case 4: for (std::size_t i = 0; i < fd::kAssistOrderPrefix * 2; ++i)  // all-equal prefix
                                base[i] = 42;
                            for (std::size_t i = fd::kAssistOrderPrefix * 2; i < n; ++i)  // strictly decreasing tail below it
                                base[i] = 40 - static_cast<std::int64_t>(i - fd::kAssistOrderPrefix * 2);
                            break;
                    case 5: for (std::size_t i = n - 1; i > n / 2; --i) base[i] = base[n / 2]; // sorted prefix, constant tail
                            break;
                    case 6: for (std::size_t k = 0; k < n / 1000 + 1; ++k) {            // few random swaps
                                std::size_t i = rng() % (n - 1); std::swap(base[i], base[i + 1]); }
                            break;
                    case 7: for (std::size_t i = 0; i < n; ++i)                          // sorted prefix, random tail
                                if (i >= fd::kAssistOrderPrefix * 2)
                                    base[i] = static_cast<std::int64_t>(rng());
                            break;
                    default: break;                                                      // plain sorted
                }
                const fyx::less less{};
                const std::greater<std::int64_t> greater{};
                {   // ascending
                    std::vector<std::int64_t> a = base, b = base;
                    fd::test_reset_dispatch();
                    const bool par = fd::try_pool_assist_order_exit(a.data(), a.size(), less, true);
                    const fd::DispatchDecision dpar = fd::test_dispatch_slot();
                    fd::test_reset_dispatch();
                    const bool ser = fd::try_fast_order_exit(b.data(), b.size(), less, true);
                    const fd::DispatchDecision dser = fd::test_dispatch_slot();
                    CHECK(par == ser, "assist and serial order verdict agree (ascending)");
                    CHECK(!par || a == b, "both proofs leave the same array (ascending)");
                    if (par) CHECK(dpar == dser, "assist and serial order decision agree (ascending)");
                    if (par) CHECK(std::is_sorted(a.begin(), a.end()), "assist proof implies sorted");
                }
                {   // descending comparator
                    std::vector<std::int64_t> a = base, b = base;
                    fd::test_reset_dispatch();
                    const bool par = fd::try_pool_assist_order_exit(a.data(), a.size(), greater, true);
                    const fd::DispatchDecision dpar = fd::test_dispatch_slot();
                    fd::test_reset_dispatch();
                    const bool ser = fd::try_fast_order_exit(b.data(), b.size(), greater, true);
                    const fd::DispatchDecision dser = fd::test_dispatch_slot();
                    CHECK(par == ser, "assist and serial order verdict agree (descending)");
                    CHECK(!par || a == b, "both proofs leave the same array (descending)");
                    if (par) CHECK(dpar == dser, "assist and serial order decision agree (descending)");
                    if (par) CHECK(std::is_sorted(a.begin(), a.end(), greater), "assist descending proof implies sorted");
                }
            }
        }
        // dispatcher wiring: with threads allowed, a 1M sorted range must be
        // proven by the assist (pool below the full-parallel floor); with
        // threads disallowed the serial detector answers identically.
        {
            const std::size_t n = std::size_t(1) << 20;
            std::vector<std::int64_t> v(n);
            for (std::size_t i = 0; i < n; ++i) v[i] = static_cast<std::int64_t>(rng() % 70000);
            std::sort(v.begin(), v.end());
            std::vector<std::int64_t> w = v;
            fd::test_reset_dispatch();
            const bool par = fd::try_order_exit_adaptive(v.data(), v.size(), fyx::less{}, true, true);
            const fd::DispatchDecision dpar = fd::test_dispatch_slot();
            fd::test_reset_dispatch();
            const bool ser = fd::try_order_exit_adaptive(w.data(), w.size(), fyx::less{}, true, false);
            CHECK(par && ser, "1M sorted range exits through both routings");
            CHECK(dpar == fd::DispatchDecision::ProfileSorted, "assist routing records ProfileSorted");
            CHECK(par == ser && v == w, "both routings agree on verdict and array");
        }
    }

    // -----------------------------------------------------------------------
    // Large-n orderedness exits.  Above kParallelOrderMinN the parallel
    // dispatcher proves sorted/reverse/all-equal with a strided sample gate, a
    // chunked classification spread over the pool and a combine step that
    // checks the chunk seams; the proof must be exactly as strong as the serial
    // one.  Sizes are odd on purpose (chunk boundaries land mid-run) and cross
    // the threshold, ascending and descending.
    // -----------------------------------------------------------------------
    std::printf("large-n parallel orderedness exits\n");
    {
        const std::size_t sizes[] = {(std::size_t(1) << 21) + 3, (std::size_t(1) << 21),
                                     (std::size_t(1) << 22) + 1};
        for (std::size_t n : sizes) {
            for (int shape = 0; shape < 5; ++shape) {
                std::vector<std::int64_t> base(n);
                for (std::size_t i = 0; i < n; ++i)
                    base[i] = static_cast<std::int64_t>(rng() % 1000000);
                std::sort(base.begin(), base.end());
                if (shape == 0) {                       // already sorted
                } else if (shape == 1) {                // reverse order
                    std::reverse(base.begin(), base.end());
                } else if (shape == 2) {                // all equal
                    for (auto& x : base) x = 7;
                } else if (shape == 3) {                // sorted but for few swaps
                    for (std::size_t k = 0; k < n / 1000 + 1; ++k) {
                        std::size_t i = rng() % (n - 1);
                        std::swap(base[i], base[i + 1]);
                    }
                } else {                                // random
                    for (auto& x : base) x = static_cast<std::int64_t>(rng());
                }
                const char* sn = shape == 0 ? "sorted" : shape == 1 ? "reverse" :
                                 shape == 2 ? "allequal" : shape == 3 ? "fewswap" : "random";
                (void)sn;
                for (int dir = 0; dir < 2; ++dir) {
                    std::vector<double> d(base.begin(), base.end());
                    std::vector<std::int32_t> w(n);
                    for (std::size_t i = 0; i < n; ++i) w[i] = static_cast<std::int32_t>(base[i]);
                    fyx::Options o;
                    o.parallel = fyx::Tri::On;
                    if (dir == 0) {
                        fyx::sort(d, o);
                        fyx::sort(w, o);
                    } else {
                        auto gt = std::greater<double>();
                        auto gt32 = std::greater<std::int32_t>();
                        std::vector<double> dref = d;
                        std::vector<std::int32_t> wref = w;
                        std::sort(dref.begin(), dref.end(), gt);
                        std::sort(wref.begin(), wref.end(), gt32);
                        fyx::sort(d.begin(), d.end(), gt, o);
                        fyx::sort(w.begin(), w.end(), gt32, o);
                        CHECK(d == dref, "large-n descending double");
                        CHECK(w == wref, "large-n descending int32");
                        continue;
                    }
                    std::vector<double> dref = d;
                    std::vector<std::int32_t> wref = w;
                    std::sort(dref.begin(), dref.end());
                    std::sort(wref.begin(), wref.end());
                    CHECK(d == dref, "large-n ascending double");
                    CHECK(w == wref, "large-n ascending int32");
                }
            }
        }
        // strings exercise the non-radix branch of the chunked detector
        {
            const std::size_t n = (std::size_t(1) << 21) + 5;
            std::vector<std::string> v(n);
            for (auto& s : v) s = std::string(6, 'a') + std::to_string(rng() % 4096);
            std::sort(v.begin(), v.end());
            std::vector<std::string> ref = v;
            fyx::Options o;
            o.parallel = fyx::Tri::On;
            fyx::detail::test_reset_dispatch();
            fyx::sort(v, o);
            CHECK(v == ref, "large-n ascending string (sorted input)");
            CHECK(fyx::detail::test_last_dispatch() == fyx::detail::DispatchDecision::ProfileSorted,
                  "large-n sorted string proved by the parallel order exit");
            std::reverse(v.begin(), v.end());
            ref = v;
            std::sort(ref.begin(), ref.end());
            fyx::sort(v, o);
            CHECK(v == ref, "large-n ascending string (reversed input)");
            CHECK(fyx::detail::test_last_dispatch() == fyx::detail::DispatchDecision::ProfileReverse,
                  "large-n reversed string proved by the parallel order exit");
        }
    }

    std::printf(failures ? "COUNTING TEST FAILURES=%d\n" : "ALL COUNTING TESTS PASS\n", failures);
    return failures ? 1 : 0;
}
